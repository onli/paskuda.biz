<?php # $Id: lang_de.inc.php 1381 2006-08-15 10:14:56Z elf2000 $

        @define('PLUGIN_EVENT_LIQUID_NAME', 'Textformatierung: Liquid');
        @define('PLUGIN_EVENT_LIQUID_DESC', 'Einfache Textformatierung durchf�hren');
        @define('PLUGIN_EVENT_LIQUID_TRANSFORM', 'Umschlie�ende Sterne machen ein Wort kursiv (*wort*), per **wort** wird es fett. [http://www.example.com Link] fungiert als URL-Tag.');
